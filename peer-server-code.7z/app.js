var express = require('express');
var app = express();
var ExpressPeerServer = require('peer').ExpressPeerServer;

app.get('/', function(req, res, next) { console.log('Someone (' + req.ip + ') said hi');res.send('I am a peerJS server! Hi! :3'); });

app.set('port', process.env.OPENSHIFT_NODEJS_PORT||3000);
app.set('ip', process.env.OPENSHIFT_NODEJS_IP || "127.0.0.1");

var server = app.listen(app.get('port'), app.get('ip'));

var options = {
    debug: true
}

app.use('/p', ExpressPeerServer(server, options));
